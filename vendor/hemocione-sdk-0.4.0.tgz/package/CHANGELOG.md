# Changelog

## 0.4.0

- Chat: mensagem `hemocione-chat:navigate` (filho → pai) com um caminho interno. O pai liga com a opção `onNavigate` e o `init` passa a levar `canNavigate: true`. `HemocioneChatChild.navigate(path)`.

## 0.3.0

- Chat: novos intents de operador em `HEMARCIO_INTENTS`: `coleta.pedido`, `coleta.pendencias`, `instituicoes.pedido`, `instituicoes.pendencias`.
- Chat: `HemocioneChatContext` documenta `audience`, `bloodBanksLocationId`, `institutionId` e `requestId`.

## 0.2.1

- Chat: novo intent `app.duvidas` em `HEMARCIO_INTENTS`.

## 0.2.0

- Chat: `chat.ask(intent, context?)` abre o chat e pede uma pergunta pronta ao Hemárcio. `HEMARCIO_INTENTS` lista os ids.
- Chat: mensagem `hemocione-chat:ask` e `HemocioneChatChild.onAsk`.
- Chat: `HemocioneChatContext` ganha `screen`, `formResponseId` e `pointType`.
- Novo `hemarcioAsk` e `canAskHemarcio`: funcionam dentro e fora de iframe.
- Canal `hemocione:*`: novos tipos `hemarcio-capable` e `open-hemarcio` para o App.

## 0.1.1

- Chat: o botão da bolha mostra só a carinha do Hemárcio (gota com olhos), sem texto visível.
- Chat: `launcherLabel` agora é só o nome acessível do botão (`aria-label` e `title`).
- Chat: offset padrão passa de 20px para 16px, mais perto do canto inferior direito.
- Chat: com o chat aberto, o botão mostra um selo de fechar (×); no celular, o botão some
  enquanto o painel está em tela cheia.

## 0.1.0

- Chat Hemárcio: bolha e modo embutido (`createHemocioneChat`).
