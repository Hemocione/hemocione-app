import { existsSync } from 'node:fs'
import { defineConfig } from 'vitest/config'

// Os testes de build rodam contra dist/. Só entram quando o build existe (o CI builda antes).
const hasDist = existsSync('dist/index.js')

export default defineConfig({
  test: {
    environment: 'jsdom',
    include: ['tests/**/*.test.ts'],
    exclude: hasDist ? [] : ['tests/build/**'],
    restoreMocks: true,
  },
})
