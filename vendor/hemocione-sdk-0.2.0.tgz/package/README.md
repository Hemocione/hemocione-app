# @hemocione/sdk

SDK oficial da Hemocione para integração com aplicações web.  
Este SDK detecta automaticamente se está rodando **dentro de um iframe** ou **fora dele** e se adapta para expor a mesma interface, utilizando comunicação com o pai via `postMessage` quando necessário.

## ✨ Principais funcionalidades

- API consistente para apps integrados via iframe ou standalone
- Comunicação entre iframe e pai baseada em `postMessage`
- Tipagem total com TypeScript
- Suporte a compartilhamento de conteúdo (`navigator.share` ou proxy via pai)

## 📦 Instalação

```bash
yarn add @hemocione/sdk
# ou
npm install @hemocione/sdk
```

## Uso

A SDK deve ser instanciada apenas do lado do cliente client. Tenha cautela com isso caso esteja utilizando tecnologias ou frameworks que permitam SSR, como Nuxt e Next.

As chamadas da SDK estão todas tipadas - utilize sua IDE para descobrir os métodos existentes.

### Uso básico - dentro do iframe

```ts
import { createHemocioneSdk } from '@hemocione/sdk'

const sdk = createHemocioneSdk()

const result = await sdk.share({
  text: 'pipipopo',
  url: 'https://hemocione.com.br',
})
```

### Uso básico - fora do iframe

```ts
import { createIframeReceiver } from '@hemocione/sdk'

const iframeListener = createIframeReceiver() // inicia o listener padrão

iframeListener.on('hemocione:share', async (data) => {
  console.log('Recebido o share')
  return {
    success: true,
  }
})
```

Você pode configurar origens permitidas:

```ts
createIframeReceiver(['https://meuapp.com'])
```

Ou passe uma função, por exemplo a lista de origens Hemocione (recomendado):

```ts
import { createIframeReceiver, isHemocioneOrigin } from '@hemocione/sdk'

createIframeReceiver(isHemocioneOrigin)
```

## Segurança e compatibilidade do canal `hemocione:*`

- `createIframeReceiver(allowedOrigins?)` aceita `string[]`, `RegExp[]` (misturados) ou uma função `(origin) => boolean`.
- **Sem lista (ou lista vazia):** aceita qualquer origem, como nas versões anteriores, e mostra **1** `console.warn` por instância. Recomendado: `createIframeReceiver(isHemocioneOrigin)`.
- **Com lista:** ignora mensagens de origem fora dela.
- Nos 2 casos, mensagens sem `event.source` são ignoradas. A resposta vai sempre para a origem de quem mandou.
- Dentro do iframe, `createHemocioneSdk({ parentOrigin })` posta para a origem exata do pai. Sem `parentOrigin`, o SDK usa `location.ancestorOrigins[0]` (Chrome, Safari, WebViews). Sem essa pista, posta com `'*'`: as mensagens deste canal não levam segredo.
- O SDK dentro do iframe só aceita respostas de `window.parent` e, quando a origem do pai é conhecida, só dessa origem.
- `destroy()` remove o listener de `IframeReceiver`.

## Chat Hemárcio

Widget do chat Hemárcio. Vanilla TS, sem dependência de runtime, estilos isolados em shadow DOM.

### Uso ESM (Nuxt, Vite)

Crie o chat **só no client** (Nuxt: plugin `.client.ts`).

```ts
import { createHemocioneChat } from '@hemocione/sdk'

const chat = createHemocioneChat({
  context: { product: 'eventos', page: location.pathname, eventSlug: 'evento-x' },
})

chat.setContext({ product: 'eventos', page: '/evento/y', eventSlug: 'y' })
chat.setToken(token) // app Capacitor: token do doador; null = logout
chat.open()
```

Modo embutido:

```ts
createHemocioneChat({ mode: 'inline', container: '#chat', context: { product: 'ondedoar' } })
```

### Uso por `<script>` (Astro, HTML)

```html
<script src="https://cdn.jsdelivr.net/npm/@hemocione/sdk@0.2.0/dist/index.global.js"></script>
<script>
  window.HemocioneSDK.createHemocioneChat({ context: { product: 'landing' } })
</script>
```

O arquivo também está em `@hemocione/sdk/iife`.

### Opções

| Opção                      | Tipo                                       | Padrão                                                                                                                                                                                            |
| -------------------------- | ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `mode`                     | `'bubble' \| 'inline'`                     | `'bubble'`                                                                                                                                                                                        |
| `container`                | `HTMLElement \| string`                    | obrigatório em `inline`                                                                                                                                                                           |
| `chatUrl`                  | `string`                                   | `'https://chat.hemocione.com.br'`. Dev: `'https://chat.d.hemocione.com.br'`. Só origens de `CHAT_ORIGINS`; `http(s)://localhost` só quando a página está em `localhost`. Outra origem lança erro. |
| `context`                  | `HemocioneChatContext`                     | `{ product: 'unknown', page: location.pathname }`                                                                                                                                                 |
| `token`                    | `string \| null`                           | `null`                                                                                                                                                                                            |
| `position`                 | `'bottom-right' \| 'bottom-left'`          | `'bottom-right'`                                                                                                                                                                                  |
| `offset`                   | `{ x?: number; y?: number }`               | `{ x: 16, y: 16 }`                                                                                                                                                                                |
| `theme`                    | `{ primaryColor?, colorScheme?, zIndex? }` | `'#bb0a08'`, `'auto'`, `2147483000`                                                                                                                                                               |
| `launcherLabel`            | `string`                                   | `'Fale com o Hemárcio'`. Só nome acessível (`aria-label` e `title`); o botão não mostra texto                                                                                                     |
| `autoOpen`                 | `boolean`                                  | `false`                                                                                                                                                                                           |
| `allowedNavigationOrigins` | `OriginMatcher`                            | `['https://id.hemocione.com.br', 'https://id.d.hemocione.com.br']`                                                                                                                                |
| `onNavigateTop`            | `(url) => void`                            | `window.location.assign(url)`                                                                                                                                                                     |
| `onOpenChange`             | `(open) => void`                           | -                                                                                                                                                                                                 |

O botão da bolha é redondo (60px) e mostra só a carinha do Hemárcio, sem texto. O SVG vem
embutido no SDK, sem requisição externa. Com o chat aberto, o botão mostra um selo de fechar (×).
No celular (até 640px), o painel abre em tela cheia e o botão some; o chat fecha pelo próprio
botão de fechar.

Métodos: `open()`, `close()`, `toggle()`, `isOpen()`, `setContext(context)`, `setToken(token)`, `ask(intent, context?)`, `destroy()`.

`HemocioneChatContext` aceita `product`, `page`, `eventSlug`, `screen` (`[a-z0-9-]`, máx. 40), `formResponseId` (24 hex) e `pointType` (`'event' | 'hemocenter'`).

Regras:

- Uma bolha por página. A segunda chamada em modo bolha devolve a instância atual (com aviso). `destroy()` libera a bolha.
- Na bolha, o iframe só é criado no primeiro `open()` (ou na criação, com `autoOpen`).
- No celular (largura até 640 px), o painel ocupa a tela inteira.
- `Esc` fecha a bolha.

### Perguntas prontas (`ask`)

`HEMARCIO_INTENTS` lista os ids: `eventos.preparar`, `possodoar.resultado`, `ondedoar.ponto`,
`app.proxima-doacao`. Os textos ficam no app do chat. Intent desconhecido lança `TypeError`.

```ts
import { hemarcioAsk, canAskHemarcio } from '@hemocione/sdk'

// Página com chat próprio
chat.ask('ondedoar.ponto', { product: 'ondedoar', screen: 'ponto', pointType: 'event' })

// Em qualquer lugar (a mesma chamada funciona dentro e fora de iframe)
if (await canAskHemarcio({ chat })) {
  await hemarcioAsk('eventos.preparar', { product: 'eventos', eventSlug: 'x' }, { chat })
}
```

- `chat.ask(intent, context?)` troca o contexto, abre o chat e entrega o `ask` uma vez. Antes do `ready` o pedido espera na fila.
- Fora de iframe, `hemarcioAsk` exige `{ chat }` e chama `chat.ask`. `canAskHemarcio` devolve `!!chat`.
- Dentro de iframe, `chat` é ignorado e o pai precisa ser uma origem Hemocione (`isHemocioneOrigin`). A origem vem de `parentOrigin`, depois `location.ancestorOrigins[0]`, depois do `document.referrer`. Origem desconhecida ou de terceiro: `canAskHemarcio` devolve `false` e `hemarcioAsk` rejeita, sem postar nada (o `context` pode ter `formResponseId`). `hemarcioAsk` envia `hemocione:open-hemarcio` ao App (`payload.data = { intent, context }`). `canAskHemarcio` envia `hemocione:hemarcio-capable` com timeout de 1500 ms e devolve `false` se o App não responder.
- No App, registre os handlers no receiver:

```ts
const receiver = createIframeReceiver(isHemocioneOrigin)
receiver.on('hemocione:hemarcio-capable', async () => ({ capable: true }))
receiver.on('hemocione:open-hemarcio', async ({ intent, context }) => chat.ask(intent, context))
```

Pelo `<script>`: `HemocioneSDK.hemarcioAsk`, `HemocioneSDK.canAskHemarcio` e `HemocioneSDK.HEMARCIO_INTENTS`.

### Protocolo pai ↔ filho

Envelope: `{ source: 'hemocione-chat', version: 1, type, payload }`.

| `type`                         | Direção     | `payload`                                                |
| ------------------------------ | ----------- | -------------------------------------------------------- |
| `hemocione-chat:ready`         | filho → pai | `{}` (postado com `'*'`, sem segredo)                    |
| `hemocione-chat:init`          | pai → filho | `{ mode, open, context, token, theme: { colorScheme } }` |
| `hemocione-chat:open`          | pai → filho | `{}`                                                     |
| `hemocione-chat:close`         | pai → filho | `{}`                                                     |
| `hemocione-chat:context`       | pai → filho | `{ context }`                                            |
| `hemocione-chat:token`         | pai → filho | `{ token }` (`null` = logout)                            |
| `hemocione-chat:ask`           | pai → filho | `{ intent }` (um id de `HEMARCIO_INTENTS`)               |
| `hemocione-chat:navigate-top`  | filho → pai | `{ url }`                                                |
| `hemocione-chat:request-close` | filho → pai | `{}` (ignorado em `inline`)                              |

Segurança:

- O pai só aceita mensagem do próprio iframe (`event.source === iframe.contentWindow`) e da origem exata do chat.
- O pai só posta depois do `ready` e sempre com `targetOrigin` = origem do chat. O token nunca vai com `'*'` e nunca vai na URL do iframe.
- O filho só aceita o primeiro `init` de `window.parent` com origem permitida. Depois grava essa origem e só aceita e posta para ela.
- `navigate-top` só navega para `http(s)` em `allowedNavigationOrigins`.

### Lado do iframe (app do chat)

```ts
import { createHemocioneChatChild } from '@hemocione/sdk'

const child = createHemocioneChatChild() // allowedParentOrigins padrão: HEMOCIONE_ORIGINS

child.onInit(({ mode, open, context, token, theme }) => {})
child.onToken((token) => {})
child.onContext((context) => {})
child.onOpen(() => {})
child.onClose(() => {})
child.onAsk((intent) => {}) // só intents do catálogo chegam aqui
child.ready() // chame depois de registrar onInit

if (child.isEmbedded()) child.navigateTop(loginUrl)
child.requestClose()
```

Fora de iframe, `ready`, `navigateTop` e `requestClose` não postam nada.

## Desenvolvimento

```bash
yarn build      # dist/index.js (ESM), dist/index.d.ts e dist/index.global.js (IIFE)
yarn test       # vitest + jsdom (os testes de build rodam quando dist/ existe)
yarn typecheck  # tsc em src/ e tests/
yarn demo       # abra http://localhost:5173/chat.html (veja demo/chat.html para origens diferentes)
```
